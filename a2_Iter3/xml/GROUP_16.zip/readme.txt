Group 16

500627132 Kevin Nguyen
500577508 Alex Grigorev
500574791 Tarenpreet Saini

Run the db.xml file in Firefox, Chrome doesn't work for some reason.